using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// ============================================================
//  EnemyFollow2D — Context Steering + Fernangriff-Modus
// ============================================================
//  Zwei Kampfmodi (Inspector-Bool "istFernkaempfer"):
//
//  NAHKÄMPFER (istFernkaempfer = false)
//    Rammt direkt Schlangensegmente. Rückstoß-Logik wie im Original.
//    Rückwärtsfahren wenn zu viele Strahlen vorne blockiert sind.
//
//  FERNKÄMPFER (istFernkaempfer = true)
//    Fährt auf Angriffsreichweite heran, bremst dann sanft ab und
//    schießt stationär Projektile auf das nächste Segment.
//    Übergangs-Geschwindigkeit zwischen Fahren und Stehen wird
//    per Lerp weich interpoliert (kein abruptes Stoppen).
//    Rückstoß-Logik entfällt (Fernkämpfer wird nicht gerammt).
//
//  Context Steering (beide Modi):
//    N radiale 3D-Raycasts erkennen Hindernisse. Bei zu vielen
//    blockierten Vorwärtsstrahlen fährt der Gegner rückwärts,
//    bis wieder freie Strahlen vorhanden sind.
//
//  Editor-Setup: siehe EnemySetup.md
// ============================================================

public class EnemyFollow2D : MonoBehaviour
{
    // --------------------------------------------------------
    //  Bewegung
    // --------------------------------------------------------
    [Header("Bewegungseinstellungen")]
    public float minSpeed = 2f;
    public float maxSpeed = 4f;
    private float currentSpeed;

    // --------------------------------------------------------
    //  Context Steering
    // --------------------------------------------------------
    [Header("Context Steering")]
    [Tooltip("Anzahl der Raycasts (mehr = genauer, teurer). Empfohlen: 8 oder 12.")]
    [Range(4, 24)]
    public int anzahlStrahlen = 8;

    [Tooltip("Reichweite der Obstacle-Raycasts.")]
    public float detektionsRadius = 2.5f;

    [Tooltip("Layer-Maske fuer Hindernisse (3D-Collider). Gegner und Schlange NICHT einbeziehen!")]
    public LayerMask hindernisLayer;

    [Tooltip("Wie stark die Lenkung pro Frame interpoliert wird. Kleiner = traeger/fahrzeugartig, Groesser = agil.")]
    [Range(1f, 20f)]
    public float lenkGeschwindigkeit = 6f;

    [Tooltip("Wie stark Interesse-Richtungen in der Naehe eines Hindernisses abgestraft werden (Spread).")]
    [Range(0f, 1f)]
    public float gefahrSpread = 0.3f;

    [Tooltip("Anteil der VORDEREN Strahlen, die blockiert sein muessen, damit Rueckwaertsfahren ausgeloest wird. " +
             "Z.B. 0.5 = mehr als die Haelfte der 'vorderen' Haelfte muss rot sein.")]
    [Range(0.1f, 1f)]
    public float rueckwaertsSchwelle = 0.6f;

    [Tooltip("Geschwindigkeit beim Rueckwaertsfahren (Faktor auf currentSpeed).")]
    [Range(0.1f, 1f)]
    public float rueckwaertsFaktor = 0.5f;

    // --------------------------------------------------------
    //  Kampfmodus
    // --------------------------------------------------------
    [Header("Kampfmodus")]
    [Tooltip("TRUE = Fernkaempfer (haelt Distanz, schiesst Projektile). " +
             "FALSE = Naehkaempfer (rammt Segmente direkt).")]
    public bool istFernkaempfer = false;

    // ── Nahkampf ──
    [Header("Nahkampf (nur wenn istFernkaempfer = false)")]
    [Tooltip("Schaden pro Rammen an ein Segment oder den allein stehenden Kopf.")]
    public float schadenAnSegment = 1f;

    [Header("Rueckstoss (nur Nahkaempfer)")]
    public float rueckstossDistanz = 1.5f;
    public float rueckstossDauer   = 0.15f;
    public float stunDauer         = 0.4f;

    // ── Fernkampf ──
    [Header("Fernkampf (nur wenn istFernkaempfer = true)")]
    [Tooltip("Distanz zur Schlange, bei der der Fernkaempfer stoppt und anfaengt zu schiessen.")]
    public float angriffsReichweite = 5f;

    [Tooltip("Hysterese: Erst ab dieser Distanz faehrt der Fernkaempfer wieder los (> angriffsReichweite).")]
    public float rueckzugReichweite = 7f;

    [Tooltip("Projektil-Prefab das abgefeuert wird.")]
    public GameObject projektilPrefab;

    [Tooltip("Feuerpause zwischen zwei Schiessen in Sekunden.")]
    public float feuerRate = 1.5f;

    [Tooltip("Geschwindigkeit des Projektils.")]
    public float projektilGeschwindigkeit = 8f;

    [Tooltip("Schaden des Projektils an einem Segment.")]
    public float projektilSchaden = 1f;

    [Tooltip("Wie schnell der Gegner abbremst wenn er in Schussreichweite kommt (0=sofort, 1=sehr traege).")]
    [Range(0f, 0.99f)]
    public float abbremsTraegheit = 0.85f;

    [Tooltip("Spawn-Offset des Projektils relativ zur Vorwaerts-Richtung des Gegners.")]
    public float projektilSpawnOffset = 0.6f;

    // --------------------------------------------------------
    //  Ausrichtung
    // --------------------------------------------------------
    [Header("Ausrichtung")]
    [Tooltip("Wohin das Sprite im Ruhezustand zeigt. Bei rechtsgerichtetem Sprite meist 0 oder -180.")]
    public float blickrichtungOffset = 0f;

    // --------------------------------------------------------
    //  Visuelles Feedback
    // --------------------------------------------------------
    [Header("Visuelles Feedback")]
    public float flashDauer = 0.1f;
    [Tooltip("Material, das beim Treffer kurz angezeigt wird. Leer lassen = kein Flash.")]
    public Material flashMaterial;

    [Header("Debug")]
    [Tooltip("Raycasts im Scene-View sichtbar machen (nur Editor).")]
    public bool debugStrahlen = false;

    // --------------------------------------------------------
    //  Interne Zustandsmaschine
    // --------------------------------------------------------
    private enum Zustand
    {
        Frei,           // Nahkaempfer: faehrt frei auf Ziel zu
        Rueckwaerts,    // Faehrt rueckwaerts weg von Hindernis
        Rueckstoss,     // Nahkaempfer: wird von Segment weggestossen
        Stun,           // Nahkaempfer: kurze Pause nach Rückstoss
        FernAnfahrt,    // Fernkaempfer: faehrt auf Schussreichweite zu
        FernAngriff,    // Fernkaempfer: steht und schiesst
    }
    private Zustand zustand = Zustand.Frei;

    private float  timer;
    private Vector2 rueckstossRichtung;
    private Vector2 aktuelleRichtung   = Vector2.right;
    private float  aktuellesFahrtempo  = 0f;   // fuer sanftes Abbremsen (Fernkaempfer)
    private float  naechsterSchuss     = 0f;

    // 2D-Trigger-Listen (Nahkampf-Schaden)
    private readonly List<Transform> ueberlappendeSegmente = new List<Transform>();
    private Transform ueberlappenderKopf;
    private Snake     kopfSnake;

    // MeshRenderer fuer Flash
    private MeshRenderer meshRenderer;
    private Material     originalMaterial;

    // Gecachtes Ziel (wird einmal pro Update bestimmt)
    private Transform aktuellesZiel;

    // --------------------------------------------------------
    //  Unity Lifecycle
    // --------------------------------------------------------
    void Start()
    {
        currentSpeed = Random.Range(minSpeed, maxSpeed);

        foreach (Transform child in GetComponentsInChildren<Transform>())
        {
            if (child.CompareTag("EnemyBody"))
            {
                meshRenderer = child.GetComponent<MeshRenderer>();
                if (meshRenderer != null)
                    originalMaterial = meshRenderer.material;
                break;
            }
        }

        // Startzustand je nach Modus
        zustand = istFernkaempfer ? Zustand.FernAnfahrt : Zustand.Frei;

        Transform ziel = FindeZiel();
        if (ziel != null)
        {
            Vector2 richtung = (Vector2)ziel.position - (Vector2)transform.position;
            aktuelleRichtung    = richtung.normalized;
            aktuellesFahrtempo  = currentSpeed;
            AusrichtenNach(aktuelleRichtung);
        }
    }

    void Update()
    {
        ueberlappendeSegmente.RemoveAll(s => s == null);
        aktuellesZiel = FindeZiel();

        if (istFernkaempfer)
            UpdateFernkaempfer();
        else
            UpdateNahkaempfer();
    }

    // --------------------------------------------------------
    //  NAHKÄMPFER – Update
    // --------------------------------------------------------
    private void UpdateNahkaempfer()
    {
        switch (zustand)
        {
            case Zustand.Frei:
                bool kopfVerwundbar = kopfSnake != null
                                      && ueberlappenderKopf != null
                                      && kopfSnake.NurKopfUebrig;

                if (ueberlappendeSegmente.Count > 0 || kopfVerwundbar)
                {
                    StarteRueckstoss(kopfVerwundbar);
                }
                else
                {
                    BewegeZuZielMitSteering(vorwaerts: true);
                }
                break;

            case Zustand.Rueckwaerts:
                BewegeZuZielMitSteering(vorwaerts: false);

                // Wieder vorwaerts wenn Strahlen frei sind
                if (!ZuVieleVordereStrahenBlockiert())
                {
                    zustand = Zustand.Frei;
                }
                break;

            case Zustand.Rueckstoss:
                float geschw = rueckstossDistanz / Mathf.Max(0.0001f, rueckstossDauer);
                Vector3 rbPos = transform.position + (Vector3)(rueckstossRichtung * geschw * Time.deltaTime);
                rbPos.z = transform.position.z;
                transform.position = rbPos;

                timer -= Time.deltaTime;
                if (timer <= 0f) { zustand = Zustand.Stun; timer = stunDauer; }
                break;

            case Zustand.Stun:
                timer -= Time.deltaTime;
                if (timer <= 0f) zustand = Zustand.Frei;
                break;
        }
    }

    // --------------------------------------------------------
    //  FERNKÄMPFER – Update
    // --------------------------------------------------------
    private void UpdateFernkaempfer()
    {
        if (aktuellesZiel == null) return;

        float distanz = Vector2.Distance(transform.position, aktuellesZiel.position);

        switch (zustand)
        {
            // ── Anfahrt zum Ziel ──
            case Zustand.FernAnfahrt:
                if (ZuVieleVordereStrahenBlockiert())
                {
                    // Rueckwaerts ausweichen, danach wieder Anfahrt
                    BewegeZuZielMitSteering(vorwaerts: false);
                }
                else
                {
                    BewegeZuZielMitSteering(vorwaerts: true);

                    // In Schussreichweite: weich abbremsen und in Angriffsmodus wechseln
                    if (distanz <= angriffsReichweite)
                    {
                        zustand = Zustand.FernAngriff;
                    }
                }
                break;

            // ── Stationaerer Angriff ──
            case Zustand.FernAngriff:
                // Sanft abbremsen (Traegheit per Frame)
                aktuellesFahrtempo = Mathf.Lerp(aktuellesFahrtempo, 0f,
                    (1f - abbremsTraegheit) * Time.deltaTime * 10f);

                // Auch wenn stehend: zur Schlange drehen und leicht nachgleiten
                if (aktuellesFahrtempo > 0.05f)
                {
                    Vector2 richtung = ((Vector2)aktuellesZiel.position - (Vector2)transform.position).normalized;
                    Vector3 gleitPos = transform.position + (Vector3)(richtung * aktuellesFahrtempo * Time.deltaTime);
                    gleitPos.z = transform.position.z;
                    transform.position = gleitPos;
                    AusrichtenNach(richtung);
                }
                else
                {
                    // Vollstaendig gestoppt: zur Schlange ausrichten
                    aktuellesFahrtempo = 0f;
                    Vector2 zielRichtung = ((Vector2)aktuellesZiel.position - (Vector2)transform.position).normalized;
                    AusrichtenNach(zielRichtung);
                }

                // Schiessen
                if (Time.time >= naechsterSchuss)
                {
                    SchiesseAufZiel();
                    naechsterSchuss = Time.time + feuerRate;
                }

                // Ziel zu weit weg (gefluechtete Schlange) → wieder anfahren
                if (distanz > rueckzugReichweite)
                {
                    aktuellesFahrtempo = 0f;   // Reset, damit Anfahrt mit Lerp von 0 startet
                    zustand = Zustand.FernAnfahrt;
                }
                break;
        }
    }

    // --------------------------------------------------------
    //  Context Steering – Kernlogik
    // --------------------------------------------------------

    // Fuehrt einen kompletten Steering-Schritt durch.
    // vorwaerts=true  → bewegt sich in Richtung Ziel
    // vorwaerts=false → bewegt sich VON Ziel weg (Rueckwaerts)
    private void BewegeZuZielMitSteering(bool vorwaerts)
    {
        Transform ziel = aktuellesZiel;
        if (ziel == null) return;

        Vector2 zumZiel = ((Vector2)ziel.position - (Vector2)transform.position).normalized;
        Vector2 zielRichtung = vorwaerts ? zumZiel : -zumZiel;

        float[] interesse  = new float[anzahlStrahlen];
        float[] gefahr     = new float[anzahlStrahlen];
        Vector2[] strahlen = new Vector2[anzahlStrahlen];

        float winkelSchritt = 360f / anzahlStrahlen;

        // ── Schritt 1: Interesse + Gefahr pro Strahl ──
        for (int i = 0; i < anzahlStrahlen; i++)
        {
            float  winkel = i * winkelSchritt;
            Vector2 dir   = Quaternion.Euler(0f, 0f, winkel) * Vector2.right;
            strahlen[i]   = dir;

            interesse[i] = Mathf.Max(0f, Vector2.Dot(dir, zielRichtung));

            Vector3 origin3D = transform.position;
            Vector3 dir3D    = new Vector3(dir.x, dir.y, 0f);

            if (Physics.Raycast(origin3D, dir3D, detektionsRadius, hindernisLayer))
            {
                gefahr[i] = 1f;
                int links  = (i - 1 + anzahlStrahlen) % anzahlStrahlen;
                int rechts = (i + 1) % anzahlStrahlen;
                gefahr[links]  = Mathf.Max(gefahr[links],  gefahrSpread);
                gefahr[rechts] = Mathf.Max(gefahr[rechts], gefahrSpread);
            }

#if UNITY_EDITOR
            if (debugStrahlen)
            {
                Color farbe = gefahr[i] >= 1f ? Color.red
                            : gefahr[i] >  0f ? Color.yellow
                            : Color.green;
                Debug.DrawRay(transform.position, dir3D * detektionsRadius, farbe);
            }
#endif
        }

        // ── Schritt 2: Besten Strahl waehlen ──
        int   besterIndex = -1;
        float besterWert  = -Mathf.Infinity;

        for (int i = 0; i < anzahlStrahlen; i++)
        {
            if (gefahr[i] >= 1f) continue;
            float wert = interesse[i] - gefahr[i];
            if (wert > besterWert) { besterWert = wert; besterIndex = i; }
        }

        Vector2 gewaehlteRichtung = (besterIndex >= 0) ? strahlen[besterIndex] : zielRichtung;

        // ── Schritt 3: Richtung interpolieren ──
        aktuelleRichtung = Vector2.Lerp(
            aktuelleRichtung,
            gewaehlteRichtung,
            lenkGeschwindigkeit * Time.deltaTime
        ).normalized;

        // ── Schritt 4: Tempo bestimmen ──
        // Fernkaempfer beschleunigt bei Anfahrt sanft aus dem Stand
        if (istFernkaempfer && zustand == Zustand.FernAnfahrt)
        {
            aktuellesFahrtempo = Mathf.Lerp(aktuellesFahrtempo, currentSpeed,
                (1f - abbremsTraegheit) * Time.deltaTime * 10f);
        }
        else
        {
            aktuellesFahrtempo = currentSpeed;
        }

        float effektivesSpeed = vorwaerts
            ? aktuellesFahrtempo
            : currentSpeed * rueckwaertsFaktor;

        // ── Schritt 5: Position aktualisieren ──
        Vector3 neuePosition = transform.position + (Vector3)(aktuelleRichtung * effektivesSpeed * Time.deltaTime);
        neuePosition.z = transform.position.z;
        transform.position = neuePosition;

        // Ausrichtung: beim Rueckwaertsfahren zeigt das Fahrzeug trotzdem noch vorne
        AusrichtenNach(vorwaerts ? aktuelleRichtung : -aktuelleRichtung);

        // ── Schritt 6: Rueckwaerts-Check fuer Nahkaempfer ──
        if (!istFernkaempfer && vorwaerts && ZuVieleVordereStrahenBlockiert())
        {
            zustand = Zustand.Rueckwaerts;
        }
    }

    // Prueft ob im vorderen Sektor (+-90° um aktuelleRichtung) ueberpropportional
    // viele Strahlen ein Hindernis melden. Wird fuer den Rueckwaerts-Trigger genutzt.
    private bool ZuVieleVordereStrahenBlockiert()
    {
        int vordereStrahen = 0;
        int blockiert      = 0;
        float winkelSchritt = 360f / anzahlStrahlen;

        for (int i = 0; i < anzahlStrahlen; i++)
        {
            float  winkel = i * winkelSchritt;
            Vector2 dir   = Quaternion.Euler(0f, 0f, winkel) * Vector2.right;

            // Nur Strahlen im vorderen Halbraum (Dot > 0)
            if (Vector2.Dot(dir, aktuelleRichtung) <= 0f) continue;
            vordereStrahen++;

            Vector3 dir3D = new Vector3(dir.x, dir.y, 0f);
            if (Physics.Raycast(transform.position, dir3D, detektionsRadius, hindernisLayer))
                blockiert++;
        }

        if (vordereStrahen == 0) return false;
        return (float)blockiert / vordereStrahen >= rueckwaertsSchwelle;
    }

    // --------------------------------------------------------
    //  Fernkampf – Projektil abfeuern
    // --------------------------------------------------------
    private void SchiesseAufZiel()
    {
        if (projektilPrefab == null || aktuellesZiel == null) return;

        Vector2 richtung = ((Vector2)aktuellesZiel.position - (Vector2)transform.position).normalized;
        Vector3 spawnPos = transform.position + (Vector3)(richtung * projektilSpawnOffset);
        spawnPos.z = transform.position.z;

        float winkel = Mathf.Atan2(richtung.y, richtung.x) * Mathf.Rad2Deg;
        GameObject projektilGO = Instantiate(projektilPrefab, spawnPos, Quaternion.Euler(0f, 0f, winkel));

        // Generischen Rigidbody-Antrieb setzen falls kein eigenes Projektil-Script vorhanden
        EnemyProjektil ep = projektilGO.GetComponent<EnemyProjektil>();
        if (ep != null)
        {
            ep.Initialisiere(richtung, projektilGeschwindigkeit, projektilSchaden);
        }
        else
        {
            // Fallback: Rigidbody2D direkt anschiessen
            Rigidbody2D rb = projektilGO.GetComponent<Rigidbody2D>();
            if (rb != null)
                rb.linearVelocity = richtung * projektilGeschwindigkeit;
        }
    }

    // --------------------------------------------------------
    //  Flash-Effekt
    // --------------------------------------------------------
    public void AufleuchtenLassen()
    {
        if (meshRenderer != null && flashMaterial != null && gameObject.activeInHierarchy)
            StartCoroutine(FlashRoutine());
    }

    private IEnumerator FlashRoutine()
    {
        meshRenderer.material = flashMaterial;
        yield return new WaitForSeconds(flashDauer);
        meshRenderer.material = originalMaterial;
    }

    // --------------------------------------------------------
    //  Nahkampf – Rückstoss
    // --------------------------------------------------------
    private void StarteRueckstoss(bool kopfVerwundbar)
    {
        Transform ziel = NaechstesUeberlapptesSegment();
        float zielDist = (ziel != null)
            ? Vector2.Distance(transform.position, ziel.position)
            : Mathf.Infinity;
        bool zielIstKopf = false;

        if (kopfVerwundbar && ueberlappenderKopf != null)
        {
            float kopfDist = Vector2.Distance(transform.position, ueberlappenderKopf.position);
            if (kopfDist < zielDist) { ziel = ueberlappenderKopf; zielIstKopf = true; }
        }

        if (ziel != null)
        {
            if (zielIstKopf)
                kopfSnake.KopfNimmtSchaden(schadenAnSegment);
            else
            {
                SnakeSegment segment = ziel.GetComponent<SnakeSegment>();
                if (segment != null) segment.NimmSchaden(schadenAnSegment);
            }

            Vector2 richtung = (Vector2)transform.position - (Vector2)ziel.position;
            rueckstossRichtung = (richtung.sqrMagnitude < 0.0001f)
                ? Random.insideUnitCircle.normalized
                : richtung.normalized;

            AusrichtenNach(-rueckstossRichtung);
        }
        else
        {
            rueckstossRichtung = Random.insideUnitCircle.normalized;
        }

        zustand = Zustand.Rueckstoss;
        timer   = rueckstossDauer;
    }

    // --------------------------------------------------------
    //  Hilfsmethoden
    // --------------------------------------------------------
    private void AusrichtenNach(Vector2 dir)
    {
        if (dir.sqrMagnitude < 0.0001f) return;
        float winkel = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg + blickrichtungOffset;
        transform.rotation = Quaternion.Euler(0f, 0f, winkel);
    }

    private Transform FindeZiel()
    {
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        if (player != null) return player.transform;
        return FindeNaechstesSegment();
    }

    private Transform FindeNaechstesSegment()
    {
        SnakeSegment[] segmente = FindObjectsOfType<SnakeSegment>();
        Transform naechstes = null;
        float kuerzesteDistanz = Mathf.Infinity;
        foreach (SnakeSegment seg in segmente)
        {
            if (seg == null) continue;
            float dist = Vector2.Distance(transform.position, seg.transform.position);
            if (dist < kuerzesteDistanz) { kuerzesteDistanz = dist; naechstes = seg.transform; }
        }
        return naechstes;
    }

    private Transform NaechstesUeberlapptesSegment()
    {
        Transform naechstes = null;
        float kuerzesteDistanz = Mathf.Infinity;
        foreach (Transform seg in ueberlappendeSegmente)
        {
            if (seg == null) continue;
            float dist = Vector2.Distance(transform.position, seg.position);
            if (dist < kuerzesteDistanz) { kuerzesteDistanz = dist; naechstes = seg; }
        }
        return naechstes;
    }

    // --------------------------------------------------------
    //  2D-Trigger (Nahkampf-Schaden)
    // --------------------------------------------------------
    private void OnTriggerEnter2D(Collider2D other)
    {
        // Fernkaempfer kollidiert nicht direkt – ignorieren
        if (istFernkaempfer) return;

        if (other.GetComponent<SnakeSegment>() != null)
        {
            if (!ueberlappendeSegmente.Contains(other.transform))
                ueberlappendeSegmente.Add(other.transform);
            return;
        }

        Snake snake = other.GetComponent<Snake>();
        if (snake != null) { ueberlappenderKopf = other.transform; kopfSnake = snake; }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (istFernkaempfer) return;

        if (other.GetComponent<SnakeSegment>() != null)
        {
            ueberlappendeSegmente.Remove(other.transform);
            return;
        }

        if (other.transform == ueberlappenderKopf) { ueberlappenderKopf = null; kopfSnake = null; }
    }
}
