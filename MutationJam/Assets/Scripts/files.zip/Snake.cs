using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(BoxCollider2D))]
public class Snake : MonoBehaviour
{
    public Transform segmentPrefab;
    public Vector2Int direction = Vector2Int.right;
    public float speed = 20f;
    public float speedMultiplier = 1f;
    public int initialSize = 4;
    public bool moveThroughWalls = false;

    [Header("Tower-Einstellungen")]
    [Tooltip("Wird an Segmente ohne eigene TurmKonfiguration uebergeben (z.B. Startsegmente)")]
    public GameObject standardTurmPrefab;

    [Header("Juice Einstellungen (LeanTween)")]
    public LeanTweenType moveEaseType = LeanTweenType.linear;
    public LeanTweenType segmentEaseType = LeanTweenType.easeOutQuad;
    public float squashAmount = 1.25f;
    public float RaupenFaktor = 0.05f;

    private readonly List<Transform> segments = new List<Transform>();
    // Spiegelt segments 1:1 – speichert die grid-exakten Logik-Positionen.
    // Tweens nutzen diese als Ziel, die Transform.position ist nur Optik.
    private readonly List<Vector3> logikPositionen     = new List<Vector3>();
    // Vorherige Logik-Positionen – fuer Richtungsberechnung pro Segment
    private readonly List<Vector3> vorigeLogikPos      = new List<Vector3>();
    private Vector2Int input;
    private float nextUpdate;

    public List<Transform> Segments => segments;

    private void Start()
    {
        ResetState();
    }

    private void Update()
    {
        if (direction.x != 0f)
        {
            if (Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow))
            {
                input = Vector2Int.up;
            }
            else if (Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow))
            {
                input = Vector2Int.down;
            }
        }
        else if (direction.y != 0f)
        {
            if (Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow))
            {
                input = Vector2Int.right;
            }
            else if (Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow))
            {
                input = Vector2Int.left;
            }
        }
    }

    private void FixedUpdate()
    {
        if (Time.fixedTime < nextUpdate)
        {
            return;
        }

        if (input != Vector2Int.zero)
        {
            direction = input;
        }

        float stepDuration = 1f / (speed * speedMultiplier);

        // --- Listen synchron halten ---
        while (logikPositionen.Count < segments.Count)
        {
            Vector3 pos = segments[logikPositionen.Count].position;
            logikPositionen.Add(pos);
            vorigeLogikPos.Add(pos);
        }
        while (logikPositionen.Count > segments.Count)
        {
            logikPositionen.RemoveAt(logikPositionen.Count - 1);
            vorigeLogikPos.RemoveAt(vorigeLogikPos.Count - 1);
        }
        // vorigeLogikPos ebenfalls auf segments-Laenge bringen
        while (vorigeLogikPos.Count < logikPositionen.Count)
            vorigeLogikPos.Add(logikPositionen[vorigeLogikPos.Count]);
        while (vorigeLogikPos.Count > logikPositionen.Count)
            vorigeLogikPos.RemoveAt(vorigeLogikPos.Count - 1);

        // --- Vorige Positionen sichern (vor dem Vorschieben) ---
        for (int i = 0; i < logikPositionen.Count; i++)
        {
            vorigeLogikPos[i] = logikPositionen[i];
        }

        // --- Logik-Positionen grid-exakt vorschieben ---
        for (int i = logikPositionen.Count - 1; i > 0; i--)
        {
            logikPositionen[i] = logikPositionen[i - 1];
        }
        int x = Mathf.RoundToInt(logikPositionen[0].x) + direction.x;
        int y = Mathf.RoundToInt(logikPositionen[0].y) + direction.y;
        logikPositionen[0] = new Vector3(x, y, 0f);

        // Kopf-Transform sofort setzen (Kollisionserkennung)
        transform.position = logikPositionen[0];

        // --- Koerper-Segmente: Tween + richtungsabhaengiger Squash ---
        for (int i = 1; i < segments.Count; i++)
        {
            if (segments[i] == null) continue;

            GameObject segGO = segments[i].gameObject;
            Vector3    ziel  = logikPositionen[i];

            // Bewegungsrichtung dieses Segments (von voriger zu neuer Logik-Position)
            Vector3 delta = logikPositionen[i] - vorigeLogikPos[i];
            bool bewegtSichHorizontal = Mathf.Abs(delta.x) > Mathf.Abs(delta.y);

            // Squash-Achsen abhaengig von Bewegungsrichtung:
            // horizontal bewegt → in X strecken, in Y quetschen (und umgekehrt)
            float zielScaleX = bewegtSichHorizontal ? squashAmount : (2f - squashAmount);
            float zielScaleY = bewegtSichHorizontal ? (2f - squashAmount) : squashAmount;
            float squashDauer = stepDuration * 0.4f;

            LeanTween.cancel(segGO);
            LeanTween.move(segGO, ziel, stepDuration * 0.85f)
                .setEase(segmentEaseType)
                .setUseEstimatedTime(true);

            GameObject cap = segGO;
            Vector3 squashZiel = new Vector3(zielScaleX, zielScaleY, 1f);
            LeanTween.scale(cap, squashZiel, squashDauer)
                .setEase(LeanTweenType.easeOutQuad)
                .setUseEstimatedTime(true)
                .setOnComplete(() =>
                {
                    if (cap != null)
                        LeanTween.scale(cap, Vector3.one, squashDauer)
                            .setEase(LeanTweenType.easeInOutQuad)
                            .setUseEstimatedTime(true);
                });
        }

        // --- Kopf-Squash (Richtung aus direction) ---
        bool kopfHorizontal = direction.x != 0;
        float kopfScaleX = kopfHorizontal ? squashAmount      : (2f - squashAmount);
        float kopfScaleY = kopfHorizontal ? (2f - squashAmount) : squashAmount;

        Vector3 kopfSquashZiel = new Vector3(kopfScaleX, kopfScaleY, 1f);
        LeanTween.scale(gameObject, kopfSquashZiel, stepDuration * 0.25f)
            .setUseEstimatedTime(true)
            .setOnComplete(() =>
            {
                LeanTween.scale(gameObject, Vector3.one, stepDuration * 0.75f)
                    .setUseEstimatedTime(true);
            });

        nextUpdate = Time.fixedTime + stepDuration;
    }

    public void Grow(Nahrungstyp typ = null)
    {
        Transform segment = Instantiate(segmentPrefab);

        // Logik-Position = aktuelle Schwanzposition (grid-exakt)
        Vector3 schwanzPos = logikPositionen.Count > 0
            ? logikPositionen[logikPositionen.Count - 1]
            : new Vector3(
                Mathf.RoundToInt(segments[segments.Count - 1].position.x),
                Mathf.RoundToInt(segments[segments.Count - 1].position.y),
                0f);

        segment.position = schwanzPos;
        logikPositionen.Add(schwanzPos);

        // Pop-In: von 0 auf 1 mit leichtem Overshoot
        segment.localScale = Vector3.zero;
        LeanTween.scale(segment.gameObject, Vector3.one, 0.25f)
            .setEase(LeanTweenType.easeOutBack)
            .setUseEstimatedTime(true);

        SnakeSegment snakeSegment = segment.gameObject.AddComponent<SnakeSegment>();
        snakeSegment.StandardTurmPrefab = standardTurmPrefab;
        snakeSegment.SetzeTyp(typ);
        snakeSegment.OnSegmentGestorben += SegmentGestorben;

        segments.Add(segment);
    }

    // Wird vom SnakeSegment-Event aufgerufen wenn ein Segment stirbt
    public void SegmentGestorben(SnakeSegment segment)
    {
        int idx = segments.IndexOf(segment.transform);
        if (idx >= 0)
        {
            segments.RemoveAt(idx);
            if (idx < logikPositionen.Count)
                logikPositionen.RemoveAt(idx);
            if (idx < vorigeLogikPos.Count)
                vorigeLogikPos.RemoveAt(idx);
        }
    }

    public void EntferneSegmente(int startIndex, int anzahl)
    {
        for (int i = startIndex; i < startIndex + anzahl; i++)
        {
            if (segments[i] != null)
            {
                LeanTween.cancel(segments[i].gameObject);
                StartCoroutine(PopOutUndZerstoere(segments[i].gameObject));
            }
        }

        segments.RemoveRange(startIndex, anzahl);

        // Hilfslisten synchron halten
        int listenAnzahl = Mathf.Min(anzahl, logikPositionen.Count - startIndex);
        if (listenAnzahl > 0)
        {
            logikPositionen.RemoveRange(startIndex, listenAnzahl);
            if (startIndex < vorigeLogikPos.Count)
                vorigeLogikPos.RemoveRange(startIndex,
                    Mathf.Min(listenAnzahl, vorigeLogikPos.Count - startIndex));
        }
    }

    private System.Collections.IEnumerator PopOutUndZerstoere(GameObject go)
    {
        float   dauer   = 0.15f;
        float   elapsed = 0f;
        Vector3 start   = go != null ? go.transform.localScale : Vector3.one;

        while (elapsed < dauer)
        {
            elapsed += Time.deltaTime;
            if (go == null) yield break;
            go.transform.localScale = Vector3.Lerp(start, Vector3.zero, elapsed / dauer);
            yield return null;
        }

        if (go != null) Destroy(go);
    }

    public void ResetState()
    {
        LeanTween.cancelAll();

        direction = Vector2Int.right;
        transform.position = Vector3.zero;
        transform.localScale = Vector3.one;

        for (int i = 1; i < segments.Count; i++)
        {
            if (segments[i] != null)
            {
                Destroy(segments[i].gameObject);
            }
        }

        segments.Clear();
        logikPositionen.Clear();
        vorigeLogikPos.Clear();

        segments.Add(transform);
        logikPositionen.Add(Vector3.zero);
        vorigeLogikPos.Add(Vector3.zero);

        for (int i = 0; i < initialSize - 1; i++)
        {
            Grow();
        }
    }

    public bool Occupies(int x, int y)
    {
        foreach (Transform segment in segments)
        {
            if (segment == null) continue;
            if (Mathf.RoundToInt(segment.position.x) == x &&
                Mathf.RoundToInt(segment.position.y) == y)
            {
                return true;
            }
        }
        return false;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Food"))
        {
            Food food = other.GetComponent<Food>();
            Nahrungstyp typ = (food != null) ? food.AktuellerTyp : null;

            Grow(typ);

            SnakeSegmentManager segmentManager = GetComponent<SnakeSegmentManager>();
            if (segmentManager != null)
            {
                segmentManager.PruefeUndZerkleinereKette();
            }

            if (food != null)
            {
                food.RandomizePosition();
            }
        }
        else if (other.gameObject.CompareTag("Obstacle"))
        {
            // FIX 2: Verhindert Selbstzerstörung durch dicke Colliders beim Tweening
            int segmentIndex = segments.IndexOf(other.transform);

            // Wenn das getroffene Objekt Teil der Schlange ist UND es sich um den direkten Hals (Index 1 oder 2) handelt:
            // Ignoriere die Kollision. Der Kopf streift den Hals nur visuell durch den Squash-Effekt.
            if (segmentIndex > 0 && segmentIndex <= 2)
            {
                return;
            }

            ResetState();
        }
        else if (other.gameObject.CompareTag("Wall"))
        {
            if (moveThroughWalls)
            {
                Traverse(other.transform);
            }
            else
            {
                ResetState();
            }
        }
    }

    private void Traverse(Transform wall)
    {
        LeanTween.cancel(gameObject);
        Vector3 position = transform.position;

        if (direction.x != 0f)
        {
            position.x = Mathf.RoundToInt(-wall.position.x + direction.x);
        }
        else if (direction.y != 0f)
        {
            position.y = Mathf.RoundToInt(-wall.position.y + direction.y);
        }

        transform.position = position;
    }
}